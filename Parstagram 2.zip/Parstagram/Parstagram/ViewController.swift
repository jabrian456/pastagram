//
//  ViewController.swift
//  Parstagram
//
//  Created by Lyndon Applewhite on 2/22/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

